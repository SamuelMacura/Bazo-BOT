from tkinter import *

from search import Search

root = Tk()
root.geometry("800x460")
root.wm_title("Bazoš BOT pro max")
root.resizable(False, False)

def create_input(obj, text, row, col):
    Label(root, text=text).grid(row=row, column=col, sticky="w")
    entry = Entry(root, textvariable=obj)
    entry.grid(row=row, column=col + 1)
    return entry


meno = create_input(StringVar(), "Názov položky obsahuje: ", 4, 0)
cenaOd = create_input(IntVar(), "Cena od: ", 5, 0)
cenaDo = create_input(IntVar(), "Cena do: ", 6, 0)
casKontroly = create_input(IntVar(), "Čas opakovania kontroly (v sekundách): ", 7, 0)
casKontroly.insert(0, str(1))
email = create_input(StringVar(), "Email na odoslanie výsledkov", 8, 0)


def create_listbox(text, row, col, options):
    label = Label(root, text=text)
    label.grid(row=row, column=col, sticky="w")
    listbox = Listbox(root, width=20, height=8, selectmode=SINGLE)
    listbox.grid(row=row, column=col + 1, rowspan=5)

    for (i, option) in options:
        listbox.insert(i, option)

    listbox.select_set(1)

    return listbox


scroll = Scrollbar(root)
# upozornenie = create_listbox("Výber upozornenia", 8, 0, [(1, "e-mail"), (2, "popup")])
kategoria = create_listbox("Výber kategórie", 4, 3,
                           [(1, "pc"), (2, "auto"), (3, "mobil"), (4, "zvierata"), (5, "deti"), (6, "reality"),
                            (7, "praca"), (8, "motocykle"), (9, "stroje"), (10, "dom"), (11, "foto"), (12, "elektro"),
                            (13, "sport"), (14, "hudba"), (15, "vstupenky"), (16, "knihy"), (17, "nabytok"),
                            (18, "oblecenie"), (19, "sluzby"), (20, "ostatne")])

kategoria.config(yscrollcommand=scroll.set)
scroll.config(command=kategoria.yview)

search = Search()

saved = [
    {
        "meno": "Prvy produkt",
        "cena": "99",
        "datum": "28.1.2022",
        "link": "https://pc.bazos.sk/graficka/100/",
    },
    {
        "meno": "Druhy produkt",
        "cena": "99",
        "datum": "28.1.2022",
        "link": "https://pc.bazos.sk/graficka/100/",
    },
    {
        "meno": "treti produkt",
        "cena": "99",
        "datum": "28.1.2022",
        "link": "https://pc.bazos.sk/graficka/100/",
    },
]


def start():
    search.spustit_casovac(meno=meno.get(), cenaOd=cenaOd.get(), cenaDo=cenaDo.get(),
                           casKontroly=casKontroly.get(),
                           kategoria=kategoria.get(ANCHOR), email=email.get(), canvas=root)
    return


Button(root, text="Vyhľadať",
       command=start, width=17).grid(row=9, column=1)

farba = Canvas(root, bg="orange", width=800, height=100).grid(row=0, column=0, pady=(0, 15), rowspan=1, columnspan=6)
Label(farba, text="Bazoš BOT", font=("Verdana", 20), bg="orange").grid(row=0, column=2)

found_products = Label(root, text="Nájdené produkty", font=("Verdana", 12))
found_products.grid(row=10, column=0, pady=(0, 10))

root.mainloop()
