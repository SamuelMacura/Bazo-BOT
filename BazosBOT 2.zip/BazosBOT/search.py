import smtplib
import webbrowser
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import Label, Button

import requests
import schedule
from bs4 import BeautifulSoup


class Search:
    baseurl = ""
    casKontroly = 60
    headers = {  # Headery, aby sa požiadavok poslal ako požiadavok prehliadača
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
    }

    found_products = []
    new_saved_products = []

    def vyhladat(self, meno, cenaOd, cenaDo, casKontroly, kategoria, email, canvas):
        baseurl = f'https://www.bazos.sk/search.php?hledat={meno}&rubriky={kategoria}&cenaod={cenaOd}&cenado={cenaDo}'
        old_found_products = self.found_products
        self.found_products = []

        request = requests.get(url=baseurl, headers=self.headers)
        scraper = BeautifulSoup(request.content, "lxml")

        product_list = scraper.find_all("div", class_="inzeraty inzeratyflex")

        for product in product_list:
            meno = product.find("h2", class_="nadpis").text.strip()
            cena = product.find('div', class_='inzeratycena').text.strip()
            datum = product.find('span', class_='velikost10').text.strip()
            link = f'https://{kategoria}.bazos.sk' + product.find('a')["href"]

            datum = str(datum).strip("TOP - [").strip("]")

            self.found_products.append({
                "meno": meno,
                "cena": cena,
                "datum": datum,
                "link": link,
            })

        new_products = []

        for product in self.found_products:
            if product not in old_found_products:
                new_products.append(product)
                self.new_saved_products.append(product)

        print(f'OLD {old_found_products}')
        print(f'NEW SEARCH {self.found_products}')
        print(f'NEW PRODUCTS {new_products}')

        if len(new_products) >= 1:
            self.poslat_email(email, self.found_products)
            self.generate(canvas)

        print(baseurl)
        # print(self.found_products)
        return self.found_products

    def spustit_casovac(self, meno, cenaOd, cenaDo, casKontroly, kategoria, email, canvas):
        schedule.clear()
        print(f'Čas kontroly {int(casKontroly)} sekúnd')
        # self.vyhladat(meno, cenaOd, cenaDo, casKontroly, kategoria, email)
        #schedule.every(int(casKontroly)).seconds.do(
         #   lambda: self.vyhladat(meno, cenaOd, cenaDo, casKontroly, kategoria, email, canvas))
        self.vyhladat(meno, cenaOd, cenaDo, casKontroly, kategoria, email, canvas)

    def poslat_email(self, mail_to_send, products):
        template = "<html><ul>"

        for product in products:
            template += f'<li><a href="{product.get("link")}"><h1 style="font-size: 20px;">{product.get("meno")} - {product.get("cena")}</h1></a><p>{product.get("datum")}</p></li>'

        template += "</ul></html>"

        message = MIMEMultipart("alternative")
        #    message.add_alternative(template.format(subtype="html"))
        message['To'] = mail_to_send
        message['From'] = "senderbazos@gmail.com"
        message['Subject'] = "BazošBot"

        message.attach(MIMEText(template, "html"))

        mail = smtplib.SMTP("smtp.gmail.com", 587)
        mail.ehlo()
        mail.starttls()

        mail.login("senderbazos@gmail.com", "BazosBot123456")
        mail.send_message(message)
        mail.close()
        print("Mail sent!")
        return

    def generate(self, canvas):
        it = 12
        for product in self.new_saved_products:
            prod = Label(canvas, text=f'{product.get("meno")} - {product.get("cena")} | {product.get("datum")}', cursor="mouse")
            prod.grid(row=it, column=0, columnspan=4, sticky="w", padx=(50, 0))
            Button(text="Zobraziť", command=lambda i=product.get("link"): webbrowser.open_new(i)).grid(row=it, column=4)
            it += 1
        return


